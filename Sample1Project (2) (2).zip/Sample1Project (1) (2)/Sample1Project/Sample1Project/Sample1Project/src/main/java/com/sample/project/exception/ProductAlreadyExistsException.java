package com.sample.project.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class ProductAlreadyExistsException extends Exception{

	public ProductAlreadyExistsException(String message) {
		super(message);
	}
	

}
