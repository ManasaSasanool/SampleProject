package com.sample.project.exception;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

public class GlobalException {
	private static final Logger logger = (Logger) LoggerFactory.getLogger(GlobalException.class);

	@ExceptionHandler(value = ProductAlreadyExistsException.class)
	public ResponseEntity<Object> exception(ProductAlreadyExistsException exception) {
		(this.logger).warn(exception.getMessage());
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.CONFLICT);

}
}