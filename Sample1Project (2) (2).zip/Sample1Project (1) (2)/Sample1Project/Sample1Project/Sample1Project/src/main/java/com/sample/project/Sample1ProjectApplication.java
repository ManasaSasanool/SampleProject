package com.sample.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication

public class Sample1ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sample1ProjectApplication.class, args);
	}

}
