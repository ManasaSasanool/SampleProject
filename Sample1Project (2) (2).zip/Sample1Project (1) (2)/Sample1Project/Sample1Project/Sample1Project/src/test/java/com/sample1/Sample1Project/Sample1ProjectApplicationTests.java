package com.sample1.Sample1Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sample1ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
