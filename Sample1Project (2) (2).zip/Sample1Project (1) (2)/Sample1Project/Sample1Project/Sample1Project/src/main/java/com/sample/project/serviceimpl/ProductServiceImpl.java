package com.sample.project.serviceimpl;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.project.entity.Product;
import com.sample.project.exception.ProductAlreadyExistsException;
import com.sample.project.repository.ProductRepository;
import com.sample.project.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	private static final Logger logger =  LoggerFactory.getLogger(Service.class);

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {

		return productRepository.findAll();
	}

	@Override
	public Product insertProduct(Product product) throws ProductAlreadyExistsException {
		Product existingProduct = this.productRepository.findByProductName(product.getProductName());
		if(null != existingProduct) {
			((org.slf4j.Logger) this.logger).warn("Product already exists, ProductName={}",product.getProductName());
			throw new ProductAlreadyExistsException("Product already exists");
		}
		return productRepository.save(product);
	}

	@Override
	public Product updateProductById(Product product) {
		Product existingProduct = productRepository.findById(product.getProductId()).orElse(null);
		existingProduct.setProductName(product.getProductName());
		existingProduct.setProductPrice(product.getProductPrice());
		existingProduct.setProductLocation(product.getProductLocation());
		
		return productRepository.save(existingProduct);
	}

	@Override
	public String deleteProductById(Long productId) {

		productRepository.deleteById(productId);
		return "Product removed !!" + productId;
	}

	@Override
	public Product getProductById(Long productId) {

		return productRepository.findById(productId).orElse(null);
	}

}
