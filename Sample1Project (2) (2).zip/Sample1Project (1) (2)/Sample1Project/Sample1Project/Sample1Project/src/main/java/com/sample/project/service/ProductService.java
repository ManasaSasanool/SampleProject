package com.sample.project.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sample.project.dto.ProductDto;
import com.sample.project.entity.Product;
import com.sample.project.exception.ProductAlreadyExistsException;
@Service
public interface ProductService {

	List<Product> getAllProducts();

	Product insertProduct(Product product) throws ProductAlreadyExistsException;

	Product getProductById(Long productId);

	Product updateProductById(Product product);

	String deleteProductById(Long productId);

	
}
