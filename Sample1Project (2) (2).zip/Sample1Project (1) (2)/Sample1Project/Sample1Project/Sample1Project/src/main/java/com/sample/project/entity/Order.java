package com.sample.project.entity;

public class Order {

}
